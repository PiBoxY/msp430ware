polymer-test-tools
==================

Common tools for testing Polymer elements. Includes a setup using [Mocha](http://visionmedia.github.io/mocha/) and [Chai](http://chaijs.com/).
