polymer-ui-action-icons
=======================

Action icon assets
