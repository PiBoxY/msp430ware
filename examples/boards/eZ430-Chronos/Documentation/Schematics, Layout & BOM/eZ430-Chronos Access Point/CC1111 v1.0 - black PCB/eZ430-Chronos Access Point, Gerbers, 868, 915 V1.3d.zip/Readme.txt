// *****************************************************************************
// Copyright 2009 BM innovations GmbH, all rights reserved. The information
// contained herein is confidential property of BM innovations GmbH.
// The use, copying, transfer or disclosure of such information is prohibited
// except by written agreement with BM innovations GmbH.
// *****************************************************************************
//
// File name:       Readme.txt
// Author:          Richard Mayerhofer
// Description:     BM-USBD1 V1.3 - PCB info for manufacturing
//
// *****************************************************************************
// Characteristics

Layers:     2
Position of layers from top to bottom
  Top     (Signal layer)
  Bottom  (Signal layer)

Material:   FR4
Thickness:  0.8 mm +-0,05 mm
Copper:     35 �

// *****************************************************************************
// File names

Gerber files. Format = Gerber RS274X. Plot files = *.pho. Info files = *.gpi
  Outline     gerber, board outline
  Top         gerber, top, copper layer
  Bottom      gerber, bottom, copper layer
  tStop       gerber, top, solder mask (stop mask)
  bStop       gerber, bottom, solder mask (stop mask)
  tCream      gerber, top, paste (cream)
  bSilkSreen  gerber, bottom, silkscreen (print white)

Drill files ( Format = Excellon ):
  Drill.exn   excellon drill file
  Drill.dri   drill info file

// *****************************************************************************
// End of file.