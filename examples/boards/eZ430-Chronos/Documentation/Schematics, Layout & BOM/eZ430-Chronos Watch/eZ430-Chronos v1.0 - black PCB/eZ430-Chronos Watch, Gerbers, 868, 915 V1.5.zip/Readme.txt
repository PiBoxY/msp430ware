// *****************************************************************************
// Copyright 2009 BM innovations GmbH, all rights reserved. The information
// contained herein is confidential property of BM innovations GmbH.
// The use, copying, transfer or disclosure of such information is prohibited
// except by written agreement with BM innovations GmbH.
// *****************************************************************************
//
// File name:       Readme.txt
// Description:     BM-WM1 V1.5 - PCB info for manufacturing
//
// *****************************************************************************
// Characteristics

Layers:     4
Position of layers and isolators from top to bottom
  Top      Copper      18 � Gold Plated   (Signal layer)
           Isolator   120 �
  L2       Copper      35 �               (GND layer)
           Isolator   230 �
  L15      Copper      35 �               (VCC layer)
           Isolator   120 �
  Bottom   Copper      18 � Gold Plated   (Signal layer)

Material:   FR4

// *****************************************************************************
// File names

Gerber files. Format = Gerber RS274X. Plot files = *.pho. Info files = *.gpi
  Outline     gerber, board outline
  Top         gerber, top, copper layer
  L2          gerber, inside, copper layer
  L15         gerber, inside, copper layer
  Bottom      gerber, bottom, copper layer
  tStop       gerber, top, solder mask (stop mask)
  bStop       gerber, bottom, solder mask (stop mask)
  tCream      gerber, top, paste (cream)
  bCream      gerber, bottom, paste (cream)

Drill files ( Format = Excellon ):
  Drill.exn   excellon drill file
  Drill.dri   drill info file

// *****************************************************************************
// End of file.