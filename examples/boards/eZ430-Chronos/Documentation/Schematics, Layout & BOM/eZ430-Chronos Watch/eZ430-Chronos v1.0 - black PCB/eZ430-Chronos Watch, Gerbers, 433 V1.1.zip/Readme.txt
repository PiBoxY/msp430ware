// *************************************************************************************************
//
// File name:       Readme.txt
// Description:     BM-WM3 V1.1 - PCB information
//
// *************************************************************************************************
// Copyright 2010 BM innovations GmbH (www.bm-innovations.com), all rights reserved.

// THIS INFORMATION IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
// OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
//
// IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
// INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF 
// THIS INFORMATION, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// *************************************************************************************************
//
// Characteristics

Layers:     4
Position of layers and isolators from top to bottom
  Top      Copper      18 � Gold Plated   (Signal layer)
           Isolator   120 �
  L2       Copper      35 �               (GND layer)
           Isolator   230 �
  L15      Copper      35 �               (VCC layer)
           Isolator   120 �
  Bottom   Copper      18 � Gold Plated   (Signal layer)

Material:   FR4

// *************************************************************************************************
// File names

Gerber files. Format = Gerber RS274X. Plot files = *.pho. Info files = *.gpi
  Outline     gerber, board outline
  Top         gerber, top, copper layer
  L2          gerber, inside, copper layer
  L15         gerber, inside, copper layer
  Bottom      gerber, bottom, copper layer
  tStop       gerber, top, solder mask (stop mask)
  bStop       gerber, bottom, solder mask (stop mask)
  tCream      gerber, top, paste (cream)
  bCream      gerber, bottom, paste (cream)

Drill files ( Format = Excellon ):
  Drill.exn   excellon drill file
  Drill.dri   drill info file

// *************************************************************************************************
// End of file.